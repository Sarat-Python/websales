from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth.forms import ReadOnlyPasswordHashField

from users.models import WebUser

# can be used at both admin and shopping sites
class WebUserCreationForm(UserCreationForm):
    """
    A form that creates a user, with no privileges, from the given email and
    password.
    """
    email = forms.EmailField(required = True)
    #password = forms.CharField(widget=forms.PasswordInput(render_value=False))
    #retype_password = forms.CharField(widget=forms.PasswordInput(render_value=False))
    first_name = forms.CharField(min_length=3, max_length= 30,required = True)
    middle_name = forms.CharField(required = False)
    last_name = forms.CharField(max_length= 30,required = True)
    mobile = forms.CharField(max_length= 20,required = True)
    mobile_model = forms.CharField(required = False, widget=forms.Select(), initial="-select-")
    unit = forms.CharField(max_length= 30,required = False)
    street = forms.CharField(max_length= 10,required = False)
    suburb = forms.CharField( max_length= 10,required = False)
    postcode = forms.CharField(max_length= 30,required = False)
    interest = forms.CharField(required = False, widget=forms.Textarea)
    
    class Meta:
        model = WebUser
        fields = ("email", "first_name",
                  "middle_name", "last_name", "mobile", "mobile_model",
                  "unit", "street", "suburb", "postcode", "interest")
    
    def __init__(self, *args, **kargs):
        super(WebUserCreationForm, self).__init__(*args, **kargs)
        del self.fields['username']
        #del self.fields['password1']
        
    def clean_email(self):
        email = self.cleaned_data['email']
        if WebUser.objects.filter(email=email).exists():
            raise ValidationError(_("Email is already registered"), code='registered')
        return email
    
    #def clean_retype_password(self):
    #    password = self.cleaned_data.get('password')
    #    retype_password = self.cleaned_data.get('retype_password')
    #    if password and retype_password and password != retype_password:
    #        raise forms.ValidationError(_("Entered password don't match!"), code='password_mismatch')
    #    return retype_password
    
    #def clean_first_name(self):
    #    first_name = self.cleaned_data['first_name']
    #    if not first_name:
    #        raise ValidationError(_("Please enter your first name"), code='blank_first_name')
    #    return first_name
    #
    #def clean_last_name(self):
    #    last_name = self.cleaned_data['last_name']
    #    if not last_name:
    #        raise ValidationError(_("Please enter your last name"), code='blank_last_name')
    #    return last_name
    #
    #def clean_mobile(self):
    #    mobile = self.cleaned_data['mobile']
    #    if not mobile:
    #        raise ValidationError(_("Please enter your mobile number"), code='blank_mobile')
    #    return mobile    
    
   

        
# Used in admin site only
class WebUserChangeForm(UserChangeForm):
    """A form for updating users. Includes all the fields on
    the user, but replaces the password field with admin's
    password hash display field.
    """
    #password1 = forms.CharField(widget=forms.PasswordInput(render_value=False))
    #password2 = forms.CharField(widget=forms.PasswordInput(render_value=False))
    
    def __init__(self, *args, **kargs):
        super(WebUserChangeForm, self).__init__(*args, **kargs)
        del self.fields['username']
    
    class Meta:
        model = WebUser
        #fields = ('password1', 'password2')
        
class WebPasswordChangeForm():
    """ A form for updating user passwords from shopping site. """
    
    password1 = forms.CharField(widget=forms.PasswordInput(render_value=False))
    password2 = forms.CharField(widget=forms.PasswordInput(render_value=False))