from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.core.context_processors import csrf
from django.template import RequestContext
from django.contrib.auth import authenticate
from django.contrib.auth import login as dj_login, logout as dj_logout
from django.views.decorators.csrf import csrf_protect

from users.models import WebUser
from users.forms import WebUserCreationForm, WebUserChangeForm

# Create your views here.
@csrf_protect
def login(request):
	if request.method == 'POST':
		email = request.POST['email']
		password = request.POST['password']
		user = authenticate(email = email, password = password)
		if user is not None:
			if user.is_active:
				dj_login(request, user)
				full_name = user.get_full_name()
				return render_to_response('loggedin.html', {'full_name': full_name}, context_instance=RequestContext(request))
			else:
				return login_handler('Account Inactive! Please activate your account')
		else:
			return HttpResponseRedirect("/user/invalid/")
		
	return render_to_response('login.html')


def logout(request):
	dj_logout(request)
	return HttpResponseRedirect('/')

@csrf_protect
def loggedin(request):
	return render_to_response('loggedin.html')
	
def invalid(request):
	return render_to_response('invalid.html')
	
@csrf_protect
def register(request):	
	if request.user != None and request.user.is_authenticated():
		return HttpResponseRedirect('/user/loggedin/')
	if request.method == 'POST':
		webuser_form = WebUserCreationForm(request.POST)
		if webuser_form.is_valid():
			webuser_form.save()
			return HttpResponseRedirect('/user/register/response',{'title':'SUCCESS'})
		else:
			return render_to_response('register.html', {'register_form':webuser_form}, context_instance=RequestContext(request))
	else:
		register_form = WebUserCreationForm()
		return render_to_response('register.html',{'register_form':register_form}, context_instance=RequestContext(request))

def activate(request):
	return render_to_response('activate.html')

def register_response(request):
	return render_to_response('response.html')

@csrf_protect
def change_password(request):
	if is_loggedin(request):
		if request.method == 'POST':
			webuser_changeform = WebUserChangeForm(request.POST)
			if webuser_changeform.is_valid():
				webuser_changeform.save()
				return HttpResponseRedirect('/user/loggedin/')
			else:
				return HttpResponseRedirect('/user/loggedin/', {'error':'Unable to update, Please try again later'})
		else:
			webuser_changeform = WebUserChangeForm()
			return render_to_response('change_password.html',{'change_form': webuser_changeform}, context_instance=RequestContext(request))

def is_loggedin(request):
	if request.user != None and request.user.is_authenticated():
		return True
	else:
		return login_handler('Login to continue')

def login_handler(error):
		return render_to_response('login.html', {'error': error})